from flask import render_template
from sqlalchemy import and_
from flask import url_for, redirect, request, make_response,flash
# Importing Session Object to use Sessions
from flask import session
from app.models import Customer, Restadmin, Items, Orders
from app import app, db



@app.route('/')
@app.route('/index')
def index():
	return render_template('index.html')

# @app.route('/about')
# def about():
# 	return render_template('about.html')


@app.route('/register')
def register():
	return render_template('userregister.html')


@app.route('/registerNext', methods = ['GET','POST'])
def registerNext():

	customer = Customer(cname=request.form["cname"], cmail=request.form["cmail"], cmobile=request.form["cmobile"], caddress=request.form["caddress"], cpassword=request.form['cpassword'])
	
	db.session.add(customer)
	db.session.commit()

	# return render_template('login.html')
	return redirect(url_for('login'))
	
	
@app.route('/login')
def login():
	return render_template('userlogin.html')


@app.route('/loginNext',methods=['GET','POST'])
def loginNext():
	# To find out the method of request, use 'request.method'
	if request.method == "GET":
		# print request.args
		cmail = request.args.get("cmail")
		cpassword = request.args.get("cpassword")
		# Can perform some password validation here
		# return "Login Successful for: %s" % cmail
	
	elif request.method == "POST":
		cmail = request.form['cmail']
		cpassword = request.form['cpassword']

		# Can perform some password validation here!
		customer  = Customer.query.filter(and_(Customer.cmail == cmail, Customer.cpassword == cpassword)).first()
		
		if customer:
			# return "login Successful for: %s" % customer.cname
			session['cmail'] = request.form['cmail']
			# return redirect(url_for('userhome'))
			return render_template('userhome.html',cusname=customer.cname)
		return "Login failed ...!"



# @app.route('/userhome')
# def userhome():
# 	# Check if userID session exists!
# 	if 'cmail' in session:
		
# 		x= Customer.query.filter_by(cmail=Customer.cmail).first()
# 		return "userhome Successful for: %s" % x.cmail 
# 		# return render_template('userhome.html')
# 	return "You are not logged in!"


@app.route('/logout')
def logout():
	# Remove the session variable if present
	session.pop('cmail',None)
	return redirect(url_for('index'))

# @app.errorhandler(404)
# def http_404_handler(error):
# 	return render_template('error404.html')